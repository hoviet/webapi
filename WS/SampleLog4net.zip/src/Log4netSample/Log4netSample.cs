using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using log4net;
namespace nthoai.blogspot.com.Log4netSample
{
    public partial class MainForm : Form
    {
        private static readonly ILog _logger = LogManager.GetLogger(typeof(MainForm).Name);
        public MainForm()
        {
            InitializeComponent();
            _logger.Debug("MainForm has been constructed");
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            _logger.Debug(this.textBoxLogMeDown.Text);
        }
    }
}